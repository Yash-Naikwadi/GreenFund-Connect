import 'package:flutter/material.dart';
import 'home_controller.dart';
import 'widgets/project_grid.dart';
import 'widgets/about_section.dart';
import '../../widgets/bottom_nav.dart';
import '../../widgets/custom_fab.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final HomeController _controller = HomeController();

  void _onItemTapped(int index) {
    setState(() {
      _controller.selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('GreenFund Connect')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: _controller.selectedIndex == 0 ? ProjectGrid() : AboutSection(),
      ),
      floatingActionButton: CustomFAB(),
      bottomNavigationBar: BottomNavBar(
        currentIndex: _controller.selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }
}
