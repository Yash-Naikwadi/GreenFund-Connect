import 'package:flutter/material.dart';

class ProjectGrid extends StatelessWidget {
  final List<String> projects = [
    "Solar Village",
    "Wind Power Hub",
    "Hydro Plant",
    "Bioenergy Farm"
  ];

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 1,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
      ),
      itemCount: projects.length,
      itemBuilder: (context, index) {
        return Card(
          elevation: 4,
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                projects[index],
                style: TextStyle(fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
            ),
          ),
        );
      },
    );
  }
}
