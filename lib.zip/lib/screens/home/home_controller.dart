class HomeController {
  int selectedIndex = 0;
}
