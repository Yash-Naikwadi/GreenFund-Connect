import 'package:flutter/material.dart';

class CustomFAB extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      backgroundColor: Colors.green,
      onPressed: () {},
      child: Icon(Icons.add),
    );
  }
}
